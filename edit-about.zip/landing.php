<?php?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="landing page for IMM News Network">
    <meta name="keywords" content="HTML, PHP, IMM, News, Network, landing page">
    <meta name="author" content="Alana Dahwoon Lee">
</head>
<body>
<a href = "hompage.php"><img src = "./articles/img/logo.png"/></a>
<br/>

<form action = "login.php" method ="POST">
<input type = "submit" name= "login" value = "LOGIN">
</form>
<form action = "signup.php" method = "POST">
<input type = "submit" name= "signup" value = "SIGNUP">
</form>
</body>
</html>